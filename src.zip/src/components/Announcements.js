import React, { useState, useEffect } from 'react';
import axios from 'axios';

function Announcements() {
  const [announcements, setAnnouncements] = useState([]);

  useEffect(() => {
    // Simulación de llamada a una API
    axios.get('/api/announcements')
      .then(response => {
        setAnnouncements(response.data);
      })
      .catch(error => console.error('Error fetching announcements:', error));
  }, []);

  return (
    <div>
      <h2>Gestión de Anuncios</h2>
      <ul>
        {announcements.map(announcement => (
          <li key={announcement.id}>{announcement.title}</li>
        ))}
      </ul>
    </div>
  );
}

export default Announcements;
