import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import Users from './components/Users';
import Issues from './components/Issues';
import Announcements from './components/Announcements';

function App() {
  return (
    <Router>
      <div>
        <nav>
          <ul>
            <li><Link to="/users">Usuarios</Link></li>
            <li><Link to="/issues">Problemas</Link></li>
            <li><Link to="/announcements">Anuncios</Link></li>
          </ul>
        </nav>

        <Routes>
          <Route path="/users" element={<Users />} />
          <Route path="/issues" element={<Issues />} />
          <Route path="/announcements" element={<Announcements />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
